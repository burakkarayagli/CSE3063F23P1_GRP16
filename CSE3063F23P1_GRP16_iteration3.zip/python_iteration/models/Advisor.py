from typing import List

from Student import Student
from Staff import Staff
from TimeInterval import TimeInterval

import logging

# Configuring logging
logging.basicConfig(
    filename="logs.log",
    level=logging.INFO,
    format="%(asctime)s:%(levelname)s:%(message)s",
)
logger = logging.getLogger(__name__)


class Advisor(Staff):
    def __init__(
        self,
        person_name: str,
        person_surname: str,
        username: str,
        password: str,
        reputation: str,
        office_hours: List[TimeInterval],
        salary: int,
        employment_status: str,
        students: List[Student],
    ):
        super().__init__(
            person_name,
            person_surname,
            username,
            password,
            reputation,
            office_hours,
            salary,
            employment_status,
        )
        self.__students = [] if students is None else students

    def __addStudent(self, student):
        return self.students.append(student)

    def __deleteStudent(self, student):
        return self.students.remove(student)

    def __studentCourseOrganization(self):
        num = 0
        for i, student in enumerate(self.students):
            print("Eligible Students")
            print("Please select one of them")
            print(f"{i + 1} {student.getFullName()}")  #'ll change

        num = int(input())
        student = self.students[num - 1]
        combined_course_list = self.__getCombinedCourses(student)

        for i, course in enumerate(combined_course_list):
            print(f"{i + 1} {course.__full_name} {course.__short_name}")

        selection = int(input())
        chosen_course = combined_course_list[selection - 1]

        if chosen_course in student.__waitingCourses:  #'ll change
            print("Course chosen by the student has been dropped.")
            student.dropCourse(chosen_course)
        else:
            print("Course has been added to the list of the student.")
            student.add_course(chosen_course)

    def __getCombinedCourses(self, student):
        combined_courses = (
            student.__waitingCourses + student.getAvailableCourses()  #'ll change
        )
        return combined_courses

    def __rejectStudent(self, student, selections):
        try:
            if selections == "*":
                student.status("Rejected")
                student.__waitingCourses.clear()  #'ll change
                return True
            else:
                rejected_courses = [
                    student.__waitingCourses[int(selection) - 1]  #'ll change
                    for selection in selections.split(",")
                ]

                for rejected_course in rejected_courses:
                    student.dropCourse(rejected_course)

            student.status("Rejected")
            # save the advisors
            data_utils = DataInitializer()
            advisors = data_utils.advisors
            for i, advisor in enumerate(advisors):
                if advisor.get_username == self.get_username():  #'ll change
                    advisors[i] = self
            data_utils.write_advisor(advisors)

            students = data_utils.students
            for i, s in enumerate(students):
                if s.get_username() == student.get_username():  #'ll change
                    students[i] = student
            data_utils.write_student(students)

            return True
        except Exception as e:
            raise Exception("Input must only include numbers. Please try again.") from e

    def __approveStudent(self, student, selections):
        try:
            if selections[0] == 0 and len(selections) == 1:
                student.status("Approved")
                # save the advisors
                data_utils = DataInitializer()
                advisors = data_utils.advisors
                for i, advisor in enumerate(advisors):
                    if advisor.username == self.username:  #'ll change
                        advisors[i] = self
                data_utils.write_advisor(advisors)  #'ll change

                students = data_utils.students
                for i, s in enumerate(students):
                    if s.username == student.username:  #'ll change
                        students[i] = student
                data_utils.write_student(students)

                return True
            else:
                status = False
                exists = False

                for i in range(len(student.__waitingCourses), 0, -1):  #'ll change
                    exists = False

                    for j in range(len(selections), 0, -1):
                        if selections[j - 1] == i:
                            exists = True
                            break

                    if not exists:
                        student.dropCourse(student.__waitingCourses[i - 1])  #'ll change
                        status = True

                student.status("Rejected" if status else "Approved")

            # save the advisors
            data_utils = DataInitializer()
            advisors = data_utils.advisors
            for i, advisor in enumerate(advisors):
                if advisor.username == self.username:
                    advisors[i] = self
            data_utils.write_advisor(advisors)  #'ll change

            students = data_utils.students
            for i, s in enumerate(students):
                if s.username == student.username:
                    students[i] = student
            data_utils.write_student(students)

            return True
        except Exception as e:
            print(f"Error in Advisor.py approve_student: {e}")
            return False

    def __approveRejectStudent(self):
        student_selection = 0

        while student_selection < 1 or student_selection > len(self.__students):
            print("Which student do you want to go on?\nType -1 to back")

            for j, student in enumerate(self.__students):
                print(f"{j + 1}- {student.getFullName()}", end="")
                # TODO: change acording to status
                print(f"({student.status})")

            try:
                student_selection = int(input())
            except ValueError:
                print("Invalid choice. Please try again.")

            if student_selection == -1:
                self.getMenu()

        student = self.__students[student_selection - 1]

        print(f"List of courses for student {student.getFullName()}")

        while True:
            print("--------------------")
            student.printwaitingCourses()
            print("select only one, type -1 to exit")
            try:
                selection = int(input())
                if selection == -1:
                    break
                print("1- Approve")
                print("2- Reject")
                selection2 = int(input())
                if selection2 == 1:
                    student.approveCourseWithIndex(selection - 1)
                elif selection2 == 2:
                    student.rejectCourseWithIndex(selection - 1)
                else:
                    print("Invalid choice. Please try again.")
                    continue
            except:
                print("Invalid choice. Please try again.")
                continue

    def getMenu(self):
        logger.info(f"Advisor({self.getFullName()}) logged)")
        # this is actually getMenu
        print(f"Welcome {self.getFullName()}")
        print("1- Manage Student Courses(Approve/Reject)")
        print("2- Information")
        print("3- Logout")

        while True:
            try:
                selection = int(input())
            except:
                print("Invalid choice. Please try again.")
                continue

            if selection == 1:
                self.getManipulationMenu()
                self.getMenu()
            elif selection == 2:
                self.getInformationMenu()
                self.getMenu()
            elif selection == 3:
                import Controller
            else:
                print("Invalid choice. Please try again.")

    def getInformationMenu(self):
        logger.info(f"Advisor({self.getFullName()}) read his/her information)")
        print("Personal Information")
        print(f"Name: {self.getFullName()}")
        print(f"Reputation: {self.reputation}")
        print(f"Student Count: {len(self.__students)}")
        print("Student Statuses: ")
        for student in self.__students:
            print(
                f"{student.getFullName()} - {'No Started' if student.status == '' else student.status}"
            )

    def getManipulationMenu(self):
        student_selection = 0

        while student_selection < 1 or student_selection > len(self.__students):
            print("Which student do you want to go on?\nType -1 to back")

            for j, student in enumerate(self.__students):
                print(f"{j + 1}- {student.getFullName()}", end="")
                print(f"({student.getWaitingCoursesLength()} Pending)")

            try:
                student_selection = int(input())
            except ValueError:
                print("Invalid choice. Please try again.")

            if student_selection == -1:
                self.getMenu()

        student = self.__students[student_selection - 1]
        logger.info(
            f"Advisor({self.getFullName()}) enter student({student.getFullName()})'s approve/reject pages)"
        )

        print(f"List of courses for student {student.getFullName()}")
        print(student.getWarnings())
        while True:
            print("--------------------")
            student.printwaitingCourses()
            print("select only one, type -1 to exit")
            try:
                selection = int(input())
                if selection == -1:
                    break
                print("1- Approve")
                print("2- Reject")
                selection2 = int(input())
                if selection2 == 1:
                    student.approveCourseWithIndex(selection - 1)
                elif selection2 == 2:
                    student.rejectCourseWithIndex(selection - 1)
                else:
                    print("Invalid choice. Please try again.")
                    continue
            except:
                print("Invalid choice. Please try again.")
                continue
        # write student here
        student.write()
        self.getMenu()

    def is_valid_format(self, selections):
        selections = selections.replace(",", "").replace(" ", "")
        try:
            int_value = int(selections)
            return True
        except ValueError:
            print(f"Exception: {ValueError}\n")
            return False

    def sort_numbers(self, input_str):
        number_strings = input_str.split(",")
        numbers = [int(number_str) for number_str in number_strings]
        numbers.sort()

        return numbers

    def add_student(self, student):
        self.__students.append(student)
        return True

    def get_student_username(self):
        return [student.username for student in self.__students]

    def toJson(self):
        return {
            "personName": self.__personName,
            "personSurname": self.__personSurname,
            "username": self.__username,
            "password": self.__password,
            "reputation": self.__reputation,
            "officeHours": [
                timeInterval.to_json() for timeInterval in self.__office_hours
            ],
            "salary": self.__salary,  #'ll change
            "employmentStatus": self.__employment_status,  #'ll change
            "students": [student.password for student in self.__students],
        }
