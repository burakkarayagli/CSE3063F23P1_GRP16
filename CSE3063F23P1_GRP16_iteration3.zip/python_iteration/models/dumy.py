from Course import Course

c = Course(
    "CSE 101",
    "Introduction to Computer Engineering",
    "Introduction to Computer Engineering",
    ["MATH 101"],
    1,
    3,
)
print(c)
